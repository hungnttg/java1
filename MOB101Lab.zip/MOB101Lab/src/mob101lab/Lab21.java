/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mob101lab;

import java.util.Scanner;

public class Lab21 {
    public static void main(String[] args) {
        //nhap
        Scanner s = new Scanner(System.in);
        System.out.println("Nhap chieu dai");
        float dai = s.nextFloat();
        System.out.println("Nhap chieu rong");
        float rong = s.nextFloat();
        //tinh toan
        float chuvi = (dai+rong)*2;
        float dientich=dai*rong;
        float min = Math.min(dai, rong);
        //xuat
        System.out.printf("Chu vi: %.0f; Dien tich: %.0f; Min: %.0f",
                chuvi,dientich,min);
        
    }
}
