/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mob101lab;

import java.util.Scanner;

public class MOB101Lab {

    public static void main(String[] args) {
        //nhap
        Scanner s = new Scanner(System.in);
        System.out.println("Ho va ten");
        String hoTen = s.nextLine();//nhap kieu chuoi
        float diem = s.nextFloat();
        //xuat
        System.out.printf("Ho ten: %s; Diem: %.1f",hoTen,diem);
        
    }
    
}
