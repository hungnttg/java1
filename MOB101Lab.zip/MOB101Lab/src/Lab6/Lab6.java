
package Lab6;

import java.util.Scanner;

public class Lab6 {
    public static void main(String[] args) {
        //tach ho ten va chuyen sang viet hoa
        String fullname="";
        Scanner s = new Scanner(System.in);
        System.out.println("Moi ban nhap ho ten");
        fullname = String.valueOf(s.nextLine());
        int kyTuSpaceDauTien = fullname.indexOf(" ");
        int kyTuSpaceCuoiCung = fullname.lastIndexOf(" ");
        //tach ho
        String ho = fullname.substring(0,kyTuSpaceDauTien);
        //tach ten
        String ten = fullname.substring(kyTuSpaceCuoiCung,fullname.length());
        //tach dem
        String dem = fullname.substring(kyTuSpaceDauTien,kyTuSpaceCuoiCung);
        System.out.println("Ho: "+ho.toUpperCase());
        System.out.println("Ten: "+ten.toUpperCase());
        System.out.println("Dem: "+dem.toLowerCase());
    }
    
}
