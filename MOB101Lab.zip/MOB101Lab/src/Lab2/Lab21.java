/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab2;

import java.util.Scanner;
public class Lab21 {//dinh nghia
    public static void main(String[] args) {
        Lab21 a = new Lab21();//tao moi 1 doi tuong
        a.BaiLab22();//goi phuong thuc (ham) cua doi tuong
    }
    public void BaiLab21()//dinh nghia ham
    {
        //Input 
        Scanner s = new Scanner(System.in);
        System.out.println("a=");
        int a = s.nextInt();
        System.out.println("a=");
        int b = s.nextInt();
        //Tinh toan
        if(a==0)
        {
            if(b==0)
            {
                System.out.println("Phuong trinh co VSN");
            }
            else
            {
                System.out.println("Phuong trinh vo nghiem");
            }
        }
        else
        {
            System.out.println("PT co nghiem x="+ (float)(-b)/a);
        }
    }
    public void BaiLab22()
    {
        //input
        Scanner s = new Scanner(System.in);
        System.out.println("a=");
        int a = s.nextInt();
        System.out.println("b=");
        int b = s.nextInt();
        System.out.println("c=");
        int c = s.nextInt();
        //tinh toan
        float delta = b*b-4*a*c;
        if(a==0)
        {
            System.out.println("La PTB1");
        }
        else
        {
            if(delta<0)
            {
                System.out.println("PT VN");
            }
            else if(delta==0)
            {
                System.out.println("PT co n duy nhat x = "+ (float)(-b)/(2*a));
            }
            else
            {
                System.out.println("x1="+(float)(-b+Math.sqrt(delta))/(2*a));
                System.out.println("x1="+(float)(-b-Math.sqrt(delta))/(2*a));
            }
        }
    }
    
}
