/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab2;

import java.util.Scanner;

/**
 *
 * @author mac
 */
public class Lab24 {
    public static void main(String[] args) {
        System.out.println("Moi ban chon chuc nang");
        System.out.println("------------");
        System.out.println("1. Giai phuong trinh bac 1");
        System.out.println("2. Giai phuong trinh bac 2");
        System.out.println("------------");
        
        Scanner s = new Scanner(System.in);
        int traloi = s.nextInt();
        Lab21 l = new Lab21();//su dung lop Lab21 bang cach tao moi doi tuong
        switch(traloi)
        {
            case 1:
                l.BaiLab21();
                break;
            case 2:
                l.BaiLab22();
                break;
            default:
                System.out.println("Khong co chuc nang tren");
                break;
        }
        
    }
}
