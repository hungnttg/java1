/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

/**
 *
 * @author mac
 */
public class SinhVien implements InterfaceSinhVien{
    public String hoTen;
    public String nganh;
    public String getHocLuc()
    {
        String xepLoai="";
        if(getDiemTB()<5)
        {
           xepLoai = "Yeu";
        }
        else if(getDiemTB()<6.5)
        {
            xepLoai = "TB";
        }
        else if(getDiemTB()<8)
        {
            xepLoai = "Kha";
        }
        else {
            xepLoai="Gioi";
        }
        return xepLoai;
    }

    @Override
    public double getDiemTB() {
        return 0;
    //chưa tính được điểm trung bình do chưa biết có những đầu điểm nào     
    }

    @Override
    public void nhap() {      
    }

    @Override
    public void xuat() {
        
    }
    
}
