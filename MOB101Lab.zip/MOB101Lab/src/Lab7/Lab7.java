/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

/**
 *
 * @author apple
 */
public class Lab7 {
    public static void main(String[] args) {
//        SInhVienIT it = new SInhVienIT();
//        it.nhap();
//        it.xuat();
    ListSinhVien<SInhVienIT> listIT = new ListSinhVien<>();//tao list sv IT
    //them 1 sinh vien vao list
    SInhVienIT it = new SInhVienIT();
    it.nhap();//nhap du lieu vao sinh vien IT
    listIT.nhap(it);//dua SV it vao List
    listIT.xuat();//xuar SV IT
        System.out.println("-----------------------");
        
        ListSinhVien<SinhVienBiz> listBiz = new ListSinhVien<>();
        //tao 1 sv biz
        SinhVienBiz biz = new SinhVienBiz();//tao sv biz moi
        biz.nhap();//nhap du lieu vao sv biz
        listBiz.nhap(biz);//dua SV biz vao list
        listBiz.xuat();//xuat ra sinh vien biz
         System.out.println("-----------------------");
    }
    
}
