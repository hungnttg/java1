/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

import java.util.Scanner;

/**
 *
 * @author apple
 */
public class SInhVienIT extends SinhVien{
    private double diemJava1, diemJava2, diemHtml;

    @Override
    public double getDiemTB() {
        return (diemJava1+diemHtml+diemJava2*2)/4; 
    }

    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("Sinh vien IT: Nhap HoTen, Nganh, DiemJava1, DIemJava2, DiemHTML");
        super.hoTen = s.nextLine();
        super.nganh = s.nextLine();
        this.diemJava1 = Double.parseDouble(s.nextLine());
        this.diemJava2 = Double.parseDouble(s.nextLine());
        this.diemHtml = Double.parseDouble(s.nextLine());
        System.out.println("Ket thuc nhap sinh vien IT");
    }

    @Override
    public void xuat() {
        super.xuat(); //To change body of generated methods, choose Tools | Templates.
        //xuat cac dau diem
        System.out.printf("HoTen: %s; Nganh: %s; DiemJava1: %.1f; DiemJava2: %.1f; DiemHTML: %.1f",
                super.hoTen, super.nganh, this.diemJava1, this.diemJava2, this.diemHtml);
    }
    
    
    
}
