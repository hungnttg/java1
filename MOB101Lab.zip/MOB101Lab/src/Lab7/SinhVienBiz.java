/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

import java.util.Scanner;

/**
 *
 * @author apple
 */
public class SinhVienBiz extends SinhVien{//sinhVienBiz ke thua tu lop SinhVien
   private double diemMKT, diemSale;
   //ghi de len phuong thuc getDiemTrungBinh
    @Override
    public double getDiemTB() {
        return (diemSale+diemMKT*2)/3;
    }
    //ghi de phuong thuc nhap (@Override) 
    @Override
    public void nhap() {
        Scanner s = new Scanner(System.in);
        System.out.println("SinhVienPiz: Nhap HoTen, Nganh, diemMKT, diemSale");
        //this: la doi tuong dang thao tac
        //super: lop cha
        //super.hoTen: truy cap thuoc tinh hoTen cua lop cha
        super.hoTen = s.nextLine();
        super.nganh = s.nextLine();
        //nhap cac dau diem
        this.diemMKT = Double.parseDouble(s.nextLine());
        this.diemSale = Double.parseDouble(s.nextLine());
        System.out.println("Ket thuc nhap");
    }
    //ghi de phuong thuc xuat (@Override)
    @Override
    public void xuat() {
        System.out.println("Xuat thong tin sinh vien biz:");
        System.out.printf("HoTen: %s, Nganh: %s, DIemMKT: %.1f, DiemSale: %.1f",
                super.hoTen, super.nganh, this.diemMKT, this.diemSale);
    }
   
    
}
