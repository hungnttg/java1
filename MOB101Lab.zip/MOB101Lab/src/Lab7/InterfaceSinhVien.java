
package Lab7;


public interface InterfaceSinhVien {
    //dinh nghia ban thiet ke cua cac phuong thuc ma sinh vien co
    public double getDiemTB();
    public void nhap();
    public void xuat();
    
}
//lập trình hướng đốitương => coi tấtcảmọithứ là đối tượng
//tinh ke thua: dung tu khoa extends => lop CaNo extends May; lop Chim extends DongVat
//Tinh da hinh: phuong thuc Keu() cua dongVat
//phan biet lop truu tuong (abstract) va giao dien (interface)
//////////
//lop truu tuong chua phuong thuc truu tuong: Keu() cua dong vat la phuong thuc truu tuong
//vì ta không biết động vật kêu cụ thể như thế nào
// không cụ thể => trừu tượng
//////
//có 2 lớp trừu tượng: Máy và Động vật
// Lớp Chim, Ca extends DongVat
// Lop MayBay, Cano extends May
//dinh nghia 2 interface: bay, boi
//chim, máy bay muốn bay được thì phải implement bay
//Cá, Cano muốn bơi được thì phải implement boi
//Lớp trừu tượng giống như thực thể
//interface giống như cách thức hoạt động
//Ví dụ: trong lớp động vật định nghĩa phương thức trừu tượng Bay
//Máy bay muốn bay được thì phải kế thừa từ lớp Động vật => vô lý
