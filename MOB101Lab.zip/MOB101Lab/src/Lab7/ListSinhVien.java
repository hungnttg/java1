/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lab7;

import java.util.ArrayList;
import java.util.List;

public class ListSinhVien<T> implements InterfaceSinhVien{
    List<SinhVien> list = new ArrayList<SinhVien>();
    //dinh nghia phuong thuc nhap moi, khong overide
    public void nhap(T t)//co the truyen SinhVienIT hoac SinhVienBiz
    {
        list.add((SinhVien)t);
    }

    @Override
    public double getDiemTB() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void nhap() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void xuat() {//doc list sinh vien
        for(SinhVien sv: list)
        {
            sv.xuat();
        }
    }
    
}
//Generic: 1 kiểu dữ liệu không xác định ở thời điểm khai báo
//Generic: chỉ xác định kiểu khi nó runtime (chạy chương trình)
//Generic: có thể nhận tất cả các kiểu dữ liệu: int, float, boolean, object,..
//Ký hiệu là <T>: trong đó T là kiểu dữ liệu generic