/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author mac
 */
public class Lab32 {
    public static void main(String[] args) {
        for(int x=1;x<10;x++)
        {
            for(int i=1;i<=10;i++)
            {
                System.out.printf("%d * %d \n",x,i,x*i);
            }
        }
                
    }
    
}
