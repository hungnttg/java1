package lab3;


import java.util.Arrays;
import java.util.Scanner;

public class Bai33 {
    public static void main(String[] args) {
        System.out.println("Moi ban nhap 1 mang so nguyen");
        Scanner s = new Scanner(System.in);
        int[] a = new int[5];//tao moi 1 mang ten la a, co 5 phan tu
        //1.nhap du lieu vao mang
        for(int i=0;i<a.length;i++)
        {
            a[i] = Integer.parseInt(s.nextLine());//nhap du lieu tu ban phim
        }
        System.out.println("Mang ban vua nhap:");
        //2.doc du lieu tu mang
        for(int j=0;j<a.length;j++)
        {
            System.out.println(a[j]);//in ra tung phan tu mang
        }
        //3. sap xep lai mang
        Arrays.sort(a);
        //4. in ra mang sau khi sap xep
        System.out.println("Mang sau khi sap xep: ");
        for(int k=0;k<a.length;k++)
        {
            System.out.println(a[k]);
        }
        //5.chia het cho 3
        int tong=0, dem=0;
        for(int k=0;k<a.length;k++)
        {
            if(a[k]%3==0)
            {
                tong += a[k];
                dem++;
            }
        }
        float trungbinhcong = (float)tong/dem;
        System.out.println("Trung binh cong phan tu chia het cho 3 la "+trungbinhcong);
    }
    
}
