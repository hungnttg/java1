
package lab3;

import java.util.Scanner;

public class Lab31 {
    public static void main(String[] args) {
        System.out.println("Moi ban nhao 1 so");
        Scanner s = new Scanner(System.in);
        int a = s.nextInt();
        boolean isSoNguyenTo = true;//bien dieu khien
        //int a1 = Integer.parseInt(s.nextLine());//convert
        for(int i=2;i<a;i++)
        {
            if(a%i==0)
            {
                isSoNguyenTo = false;//khong phai so nguyen to
                break;
            }
        }
        //kiem tra bien dieu khien
        if(isSoNguyenTo==true)
        {
            System.out.println(a + " la so nguyen to");
        }
        else
        {
            System.out.println(a +" phong phai so nguyen to");
        }
    
    }
    
}
