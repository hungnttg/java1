
package lab3;

import java.util.Scanner;

public class Lab34 {
    public static void main(String[] args) {
        System.out.println("Moi ban nhap ho ten- diem");
        Scanner s = new Scanner(System.in);
        String[] hoTen = new String[4];
        String[] hocLuc = new String[4];
        float[] diem = new float[4];
        //1. nhap
        for(int i=0;i<hoTen.length;i++)
        {
            hoTen[i] = s.nextLine();//nhap ho ten
            diem[i] = Float.parseFloat(s.nextLine());//nhap diem, chuyen sang so thuc
            if(diem[i]<5)
            {
                hocLuc[i] = "Yeu";
            }
            else if(diem[i]<6.5)
            {
                hocLuc[i] = "TB";
            }
            else if(diem[i]<7.5)
            {
                hocLuc[i]="Kha";
            }
            else
            {
                hocLuc[i]="Gioi";
            }
        }
        //2. in ra man hinh
        System.out.println("Ban vua nhap");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; Diem: %.1f; Hoc LucL %s \n",
                    hoTen[i],diem[i],hocLuc[i]);
        }
        //3. Sap xep theo diem
        for(int i=0;i<hoTen.length-1;i++)//lay tu phan tu dau den gan cuoi
        {
            for(int j=i+1;j<hoTen.length;j++)//lay phan tu so 2 den cuoi
            {
                if(diem[i]>diem[j])
                {
                    float tam = diem[i];
                    diem[i] = diem[j];
                    diem[j] = tam;
                    
                    String ht = hoTen[i];
                    hoTen[i] = hoTen[j];
                    hoTen[j] = ht;
                    
                    String hluc = hocLuc[i];
                    hocLuc[i] = hocLuc[j];
                    hocLuc[j] = hluc;
                }
            }
        }
        System.out.println("Mang sau khi sap xep theo diem");
        for(int i=0;i<hoTen.length;i++)
        {
            System.out.printf("Ho ten: %s; Diem: %.1f; Hoc LucL %s \n",
                    hoTen[i],diem[i],hocLuc[i]);
        }
        try {
            for(float i:diem)
            {
                System.out.println(i);
            }
            
        } catch (Exception e) {
            e.printStackTrace();//neu xay ra loi
        }
        
    }
    
}
