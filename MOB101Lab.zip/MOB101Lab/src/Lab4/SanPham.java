
package Lab4;

import java.util.Scanner;
//Dinh nghia lop
public class SanPham {
    //khai bao cac thuoc tinh
    private String tenSP;
    private double donGia;
    private double giamGia;
    //khai bao cac phuong thuc
    public double thueNhapKhau(){
        double tnk = donGia - donGia*0.1;//tinh toan
        //double tnk1 = this.donGia - this.donGia*0.1;
        return tnk;//tra ve ket qua
    }
    public void xuat(){
        System.out.println("Thong tin san pham vua nhap");
        System.out.printf("Ten SP: %s", tenSP);
        System.out.printf("Don gia: %.1f",donGia);
        System.out.printf("Giam gia: %.1f",giamGia);
    }
    public void nhap()
    {
        System.out.println("Moi ban nhap: TenSP, Don gia, Giam gia");
        Scanner a = new Scanner(System.in);
        tenSP = a.nextLine();
        donGia = Double.parseDouble(a.nextLine());
        giamGia = Double.parseDouble(a.nextLine());
    }
    //phuong thuc khoi tao

    public SanPham(String tenSP, double donGia, double giamGia) {
        this.tenSP = tenSP;
        this.donGia = donGia;
        this.giamGia = giamGia;
    }

    public SanPham() {
    }
   
    
    
    
    //////////
    public String getTenSP() {
        return tenSP;
    }

    public double getDonGia() {
        return donGia;
    }

    public double getGiamGia() {
        return giamGia;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public void setGiamGia(double giamGia) {
        this.giamGia = giamGia;
    }
    
    
}
