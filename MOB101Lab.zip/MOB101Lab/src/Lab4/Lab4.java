
package Lab4;

//dung de goi
public class Lab4 {
       public static void main(String[] args) {
           //Su dung lop
           SanPham s1 = new SanPham();
           SanPham s2 = new SanPham("A1", 10, 1);
         
           s1.nhap();
           s1.xuat();
       }
    
}
