/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class SinhVien {
    private String hoTen;
    ///cac phuong thuc thong thuong////
    
    private ArrayList<String> list = new ArrayList<>();//tao 1 mang luu ten SV
    public void nhap()
    {
        Scanner s = new Scanner(System.in);
        String qd;//bien luu quyet dinh co nhap tiep hay khong
        boolean yn = true;//bien dieu khien vong lap
        while(yn)//dua vao vong lap de nhap du lieu
        {
            System.out.println("Moi ban nhap ho ten");
            hoTen = String.valueOf(s.nextLine());//lay gia tri nhap ban phim
            //dua du lieu vao list
            list.add(hoTen);
            //nhap quyet dinh xem co nhap du lieu tiep hay khong
            qd = String.valueOf(s.nextLine());//nhap Y hoac N
            switch(qd)//kiem tra xem quyet dinh la gi
            {
                case "Y":
                    yn = true;//quyet dinh nhap tiep
                    break;
                case "N":
                    yn=false;
                    break;
                default:
                    System.out.println("Hay nhap lai ho ten");
                        
            }
        
        }
        System.out.println("------Ket thuc nhap lieu--------");
    }
    public void xuat()//phuong thuc xuat du lieu
    {
        System.out.println("---------------");
        System.out.println("Danh sach sinh vien ban vua nhap");
        for(String x: list)//su dung for each
        {
            System.out.println(x.toString());
        }
    }
    public void xuatNgauNhien()//phuong thuc xuat du lieu
    {
        System.out.println("---------------");
        System.out.println("Danh sach sinh vien ban vua nhap");
        Collections.shuffle(list);//sap xep ngau nhien
        for(String x: list)//su dung for each
        {
            System.out.println(x.toString());
        }
    }
    public void xuatTangDan()//phuong thuc xuat du lieu
    {
        System.out.println("---------------");
        System.out.println("Danh sach sinh vien ban vua nhap");
        Collections.shuffle(list);//sap xep ngau nhien
        Collections.sort(list);//sap xep theo danh sach tang dan
        for(String x: list)//su dung for each
        {
            System.out.println(x.toString());
        }
    }
        public void xuatGiamDan()//phuong thuc xuat du lieu
    {
        System.out.println("---------------");
        System.out.println("Danh sach sinh vien ban vua nhap");
        Collections.shuffle(list);//sap xep ngau nhien
        Collections.sort(list);//sap xep theo danh sach tang dan
        Collections.reverse(list);//sap xep theo danh sach giam dan
        for(String x: list)//su dung for each
        {
            System.out.println(x.toString());
        }
    }
    
    ///// cac phuong thuc tu tao//////
    public SinhVien() {
    }

    public SinhVien(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }
    //////
    
    
}
